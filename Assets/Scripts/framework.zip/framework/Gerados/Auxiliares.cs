public enum Auxiliares
{
    Baixo,
    Cima,
    Direita,
    Esquerda,
}
