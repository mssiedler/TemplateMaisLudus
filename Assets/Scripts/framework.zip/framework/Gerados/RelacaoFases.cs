public enum RelacaoFases
{
    amanda2,
    brinquedos,
    cores,
    diferente,
    diferenteParaClique,
    exemplo,
    exemplotrocado,
    formas,
    partescorpo,
    pintarfrutas,
}
